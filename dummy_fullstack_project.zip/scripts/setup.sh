echo "Setting up project..."
